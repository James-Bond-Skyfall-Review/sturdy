import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Calculates combinations nCr using a more stable iterative approach
 */
export function combinations(n: number, r: number): number {
  if (r < 0 || r > n) return 0;
  if (r === 0 || r === n) return 1;
  if (r > n / 2) r = n - r;

  let res = 1;
  for (let i = 1; i <= r; i++) {
    res = (res * (n - i + 1)) / i;
    // Cap at a safe limit to avoid Infinity issues in standard JS numbers
    if (res > Number.MAX_SAFE_INTEGER * 1e10) return Infinity;
  }
  return res;
}

/**
 * Masaniello Weighting Function: Sum_{i=k}^n [combinations(n, i) * (odds - 1)^(n - i)]
 */
export function masanielloWeight(n: number, k: number, odds: number): number {
  if (k > n) return 0;
  if (k <= 0) return Math.pow(odds, n); // Simplified for all wins
  
  let sum = 0;
  const qMinusOne = odds - 1;
  
  for (let i = k; i <= n; i++) {
    const term = combinations(n, i) * Math.pow(qMinusOne, n - i);
    sum += term;
    if (sum === Infinity) break;
  }
  return sum;
}

/**
 * Calculate the next stake (Puntata)
 * Standard formula for Masaniello progression
 */
export function calculateNextStake(B: number, m: number, r: number, Q: number): number {
  if (r <= 0) return 0;
  if (r > m) return 0;
  
  const f_m_r = masanielloWeight(m, r, Q);
  const f_prev_win = masanielloWeight(m - 1, r - 1, Q);
  
  if (f_m_r === 0 || !isFinite(f_m_r)) return 0;

  // Stake formula derived from yield parity
  const numerator = (Q * f_prev_win) - f_m_r;
  const denominator = (Q - 1) * f_m_r;
  
  let stake = B * (numerator / denominator);
  
  // Sanity check: stake cannot be negative or more than current bankroll
  if (stake < 0) stake = 0;
  if (stake > B) stake = B;
  
  return stake;
}

/**
 * Calculate the target payout (Capitale Finale)
 */
export function calculateTarget(initialCapital: number, n: number, k: number, odds: number): number {
  const weight = masanielloWeight(n, k, odds);
  return initialCapital * (Math.pow(odds, n) / weight);
}
