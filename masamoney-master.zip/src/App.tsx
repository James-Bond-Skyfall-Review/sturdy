/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  TrendingUp, 
  Settings2, 
  RotateCcw, 
  Plus, 
  History, 
  ChevronRight, 
  Info,
  CheckCircle2,
  XCircle,
  Wallet,
  Target,
  BarChart3,
  Undo2,
  Trophy,
  Skull
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { cn } from './lib/masaLogic';
import { 
  calculateNextStake, 
  calculateTarget 
} from './lib/masaLogic';

// --- Types ---

interface MasanielloState {
  initialCapital: number;
  totalEvents: number;
  expectedWins: number;
  odds: number;
  history: Array<'W' | 'L'>;
}

interface HistoryItem {
  eventNumber: number;
  outcome: 'W' | 'L';
  stake: number;
  bankrollBefore: number;
  bankrollAfter: number;
}

// --- App Component ---

export default function App() {
  const [state, setState] = useState<MasanielloState | null>(() => {
    const saved = localStorage.getItem('masa_state_v2');
    return saved ? JSON.parse(saved) : null;
  });

  const [setupMode, setSetupMode] = useState(!state);
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  useEffect(() => {
    if (state) {
      localStorage.setItem('masa_state_v2', JSON.stringify(state));
    } else {
      localStorage.removeItem('masa_state_v2');
    }
  }, [state]);

  const handleStart = (config: MasanielloState) => {
    setState(config);
    setSetupMode(false);
  };

  const executeReset = () => {
    setState(null);
    setSetupMode(true);
    setShowConfirmReset(false);
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 font-sans selection:bg-blue-100">
      {/* Reset Confirmation Overlay */}
      <AnimatePresence>
        {showConfirmReset && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl p-8 max-w-sm w-full shadow-2xl border border-slate-200 text-center"
            >
              <div className="bg-rose-100 text-rose-600 p-3 rounded-2xl w-fit mx-auto mb-4">
                <RotateCcw className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-black mb-2">Reset Session?</h3>
              <p className="text-slate-500 text-sm mb-8">This will permanently delete your current bankroll progression.</p>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => setShowConfirmReset(false)}
                  className="py-3 bg-slate-100 hover:bg-slate-200 rounded-xl text-sm font-bold transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={executeReset}
                  className="py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-rose-200"
                >
                  Confirm Reset
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dynamic Header */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3" onClick={() => !setupMode && setShowConfirmReset(true)}>
            <div className="bg-blue-600 p-2 rounded-xl shadow-lg shadow-blue-200 cursor-pointer">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div className="cursor-pointer">
              <h1 className="text-sm sm:text-base font-bold tracking-tight text-slate-900 leading-none">MasaMaster</h1>
              <p className="text-[10px] uppercase tracking-widest font-black text-slate-400 mt-1 hidden sm:block">Light Edition</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {!setupMode && (
              <button 
                onClick={() => setShowConfirmReset(true)}
                className="flex items-center gap-2 px-3 sm:px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:text-blue-600 hover:bg-blue-50 transition-all rounded-full"
              >
                <RotateCcw className="w-3.5 h-3.5 sm:w-4 h-4" />
                <span className="hidden xs:inline">Reset</span>
              </button>
            )}
          </div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {setupMode ? (
            <SetupView key="setup" onStart={handleStart} initialValues={state} />
          ) : state ? (
            <Dashboard 
              key="dashboard" 
              state={state} 
              setState={setState} 
              onReset={() => setShowConfirmReset(true)} 
            />
          ) : null}
        </AnimatePresence>
      </main>

      <footer className="py-12 px-4 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-full shadow-sm text-xs font-semibold text-slate-400">
          <Info className="w-3.5 h-3.5" />
          Advanced Probabilistic Bankroll Management
        </div>
      </footer>
    </div>
  );
}

// --- Setup View ---

function SetupView({ onStart, initialValues }: { onStart: (config: MasanielloState) => void; initialValues: MasanielloState | null }) {
  const [form, setForm] = useState({
    initialCapital: initialValues?.initialCapital || 100,
    totalEvents: initialValues?.totalEvents || 20,
    expectedWins: initialValues?.expectedWins || 15,
    odds: initialValues?.odds || 2.0
  });

  const [error, setError] = useState<string | null>(null);

  const target = useMemo(() => {
    if (form.expectedWins > form.totalEvents || form.expectedWins <= 0) return 0;
    return calculateTarget(form.initialCapital, form.totalEvents, form.expectedWins, form.odds);
  }, [form]);

  const handleSubmit = () => {
    if (form.expectedWins > form.totalEvents) {
      setError("Expected wins cannot exceed total events.");
      return;
    }
    if (form.expectedWins <= 0 || form.totalEvents <= 0 || form.initialCapital <= 0 || form.odds < 0) {
      setError("All values must be positive numbers.");
      return;
    }
    onStart({ ...form, history: [] });
  };

  const yieldPct = ((target / form.initialCapital) - 1) * 100;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }} 
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="max-w-xl mx-auto space-y-6"
    >
      <div className="text-center space-y-2 mb-8">
        <h2 className="text-3xl font-black text-slate-900 tracking-tight">Setup Your Strategy</h2>
        <p className="text-slate-500 font-medium">Define your goals and let the algorithm handle the risk.</p>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 p-6 sm:p-8 space-y-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-6">
          <InputGroup 
            label="Initial Bankroll" 
            icon={Wallet} 
            value={form.initialCapital} 
            onChange={v => setForm(f => ({ ...f, initialCapital: Number(v) }))}
          />
          <InputGroup 
            label="Event Odds" 
            icon={Settings2} 
            step="0.01"
            value={form.odds} 
            onChange={v => setForm(f => ({ ...f, odds: Number(v) }))}
          />
          <InputGroup 
            label="Total Events" 
            icon={History} 
            value={form.totalEvents} 
            onChange={v => setForm(f => ({ ...f, totalEvents: Number(v) }))}
          />
          <InputGroup 
            label="Expected Wins" 
            icon={Target} 
            value={form.expectedWins} 
            onChange={v => setForm(f => ({ ...f, expectedWins: Number(v) }))}
          />
        </div>

        {error && (
          <div className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600 text-sm font-semibold">
            <Info className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}

        <div className="bg-slate-50 rounded-2xl p-4 sm:p-6 border border-slate-100 flex flex-col items-center text-center">
          <p className="text-[10px] uppercase tracking-widest font-black text-slate-400 mb-2">Projected Result</p>
          <div className="text-3xl sm:text-4xl font-black text-blue-600 tabular-nums leading-none">
            €{target.toFixed(2)}
          </div>
          <div className={cn(
            "mt-3 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wide",
            yieldPct > 0 ? "bg-emerald-100 text-emerald-700" : "bg-slate-200 text-slate-600"
          )}>
            {yieldPct > 0 ? "+" : ""}{yieldPct.toFixed(1)}% RETURN
          </div>
        </div>

        <button 
          onClick={handleSubmit}
          className="w-full bg-slate-900 hover:bg-blue-600 text-white font-black py-5 rounded-2xl transition-all shadow-xl shadow-slate-200 active:scale-[0.98] flex items-center justify-center gap-3"
        >
          Generate Progression
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </motion.div>
  );
}

// --- Dashboard ---

function Dashboard({ state, setState, onReset }: { 
  state: MasanielloState; 
  setState: React.Dispatch<React.SetStateAction<MasanielloState | null>>;
  onReset: () => void;
}) {
  const { initialCapital, totalEvents, expectedWins, odds, history } = state;

  const derived = useMemo(() => {
    let currentBankroll = initialCapital;
    let wins = 0;
    const items: HistoryItem[] = [];

    for (let i = 0; i < history.length; i++) {
      const m = totalEvents - i;
      const r = expectedWins - wins;
      const stake = calculateNextStake(currentBankroll, m, r, odds);
      const outcome = history[i];

      const before = currentBankroll;
      if (outcome === 'W') {
        currentBankroll += stake * (odds - 1);
        wins++;
      } else {
        currentBankroll -= stake;
      }

      items.push({
        eventNumber: i + 1,
        outcome,
        stake,
        bankrollBefore: before,
        bankrollAfter: currentBankroll
      });
    }

    return {
      currentBankroll,
      wins,
      losses: history.length - wins,
      historyItems: items
    };
  }, [state]);

  const nextStake = useMemo(() => {
    const passed = history.length;
    const winsNeeded = expectedWins - derived.wins;
    const left = totalEvents - passed;
    
    if (winsNeeded <= 0) return 0; // Win series
    if (winsNeeded > left) return -1; // Loss series
    
    return calculateNextStake(derived.currentBankroll, left, winsNeeded, odds);
  }, [state, derived]);

  const targetValue = calculateTarget(initialCapital, totalEvents, expectedWins, odds);
  const progress = Math.min(100, Math.max(0, (derived.wins / expectedWins) * 100));
  const isComplete = nextStake <= 0;

  const chartData = useMemo(() => {
    const data = [{ x: 0, b: initialCapital }];
    derived.historyItems.forEach(h => data.push({ x: h.eventNumber, b: h.bankrollAfter }));
    return data;
  }, [derived]);

  const update = (outcome: 'W' | 'L') => {
    setState(s => s ? ({ ...s, history: [...s.history, outcome] }) : null);
  };

  const undo = () => {
    setState(s => s ? ({ ...s, history: s.history.slice(0, -1) }) : null);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Left Wall: Controls & Status */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-6 overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-5">
            <Target className="w-24 h-24 stroke-slate-900" />
          </div>

          <div className="relative space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-black uppercase text-slate-400 tracking-tighter">Current Stake</h3>
              <div className="px-2 py-1 bg-slate-100 rounded-lg text-[10px] font-black text-slate-500">
                FIXED ODDS {odds.toFixed(2)}
              </div>
            </div>

            <div className="text-center py-4 bg-slate-50 rounded-2xl border border-slate-100">
              <span className="text-5xl font-black text-slate-900 tabular-nums">
                {isComplete ? (nextStake === 0 ? "DONE" : "OUT") : `€${nextStake.toFixed(2)}`}
              </span>
            </div>

            {!isComplete ? (
              <div className="grid grid-cols-2 gap-4">
                <ActionButton label="WIN" color="emerald" icon={CheckCircle2} onClick={() => update('W')} />
                <ActionButton label="LOSS" color="rose" icon={XCircle} onClick={() => update('L')} />
              </div>
            ) : (
              <div className={cn(
                "p-4 rounded-2xl flex flex-col items-center text-center space-y-2",
                nextStake === 0 ? "bg-emerald-50 text-emerald-700 border border-emerald-100" : "bg-rose-50 text-rose-700 border border-rose-100"
              )}>
                {nextStake === 0 ? <Trophy className="w-8 h-8" /> : <Skull className="w-8 h-8" />}
                <p className="text-sm font-black">
                  {nextStake === 0 ? "GOAL ACHIEVED" : "SERIES EXHAUSTED"}
                </p>
                <button 
                  onClick={onReset}
                  className="w-full mt-2 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-slate-200"
                >
                  Start New Session
                </button>
                <button 
                  onClick={undo}
                  className="mt-2 text-xs font-bold text-slate-400 hover:text-slate-600 underline"
                >
                  Edit last entry
                </button>
              </div>
            )}

            {history.length > 0 && !isComplete && (
              <button 
                onClick={undo}
                className="w-full text-center py-2 text-xs font-bold text-slate-400 hover:text-slate-900 transition-colors uppercase tracking-widest flex justify-center items-center gap-2"
              >
                <Undo2 className="w-3.5 h-3.5" />
                Undo Entry
              </button>
            )}
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">Configuration</h4>
          <div className="space-y-2.5">
            <StatRow label="Event Progress" value={`${history.length} / ${totalEvents}`} />
            <StatRow label="Wins Captured" value={`${derived.wins} / ${expectedWins}`} />
            <StatRow label="Wins Needed" value={Math.max(0, expectedWins - derived.wins)} />
            <div className="pt-2">
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  className="h-full bg-blue-600 rounded-full"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Wall: Analytics & History */}
      <div className="lg:col-span-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <BentoStat 
            label="Available Funds" 
            value={`€${derived.currentBankroll.toFixed(2)}`} 
            sub={`Goal: €${targetValue.toFixed(2)}`}
            icon={Wallet} 
          />
          <BentoStat 
            label="Profit / Loss" 
            value={`€${(derived.currentBankroll - initialCapital).toFixed(2)}`} 
            sub={`Yield: ${(((derived.currentBankroll/initialCapital)-1)*100).toFixed(1)}%`}
            icon={BarChart3}
            trend={derived.currentBankroll >= initialCapital ? 'up' : 'down'}
          />
        </div>

        <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-sm">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-lg font-black tracking-tight text-slate-900">Capital Flow</h3>
            <div className="flex gap-4">
              <span className="flex items-center gap-2 text-[10px] font-black uppercase text-slate-400">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600" /> Progression
              </span>
            </div>
          </div>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="glow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="x" hide />
                <YAxis 
                  domain={['dataMin - 10', 'dataMax + 10']} 
                  orientation="right" 
                  stroke="#94a3b8" 
                  fontSize={10} 
                  fontWeight="bold"
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={v => `€${Math.round(v)}`}
                />
                <Tooltip 
                  cursor={{ stroke: '#cbd5e1', strokeWidth: 1 }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-white border border-slate-200 shadow-xl rounded-xl p-3">
                          <p className="text-[10px] font-black text-slate-400 mb-1 uppercase tracking-widest">Balance @ Event {payload[0].payload.x}</p>
                          <p className="text-lg font-black text-slate-900">€{Number(payload[0].value).toFixed(2)}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="b" 
                  stroke="#2563eb" 
                  strokeWidth={4} 
                  fill="url(#glow)" 
                  animationDuration={1500}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center">
            <h3 className="text-xs font-black uppercase text-slate-400">Activity History</h3>
            <History className="w-4 h-4 text-slate-300" />
          </div>
          
          {/* Mobile Card View */}
          <div className="block sm:hidden divide-y divide-slate-100">
            {history.length === 0 ? (
              <div className="px-6 py-12 text-center text-slate-400 text-xs font-medium italic">
                Recording will appear here once you start.
              </div>
            ) : (
              [...derived.historyItems].reverse().map(item => (
                <div key={item.eventNumber} className="p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black text-slate-400 uppercase">Event #{item.eventNumber}</span>
                    <div className={cn(
                      "px-2 py-0.5 rounded-full text-[9px] font-black uppercase",
                      item.outcome === 'W' ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
                    )}>
                      {item.outcome === 'W' ? "Win" : "Loss"}
                    </div>
                  </div>
                  <div className="flex justify-between items-end">
                    <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase leading-none mb-1">Staked</p>
                      <p className="text-sm font-black text-slate-900">€{item.stake.toFixed(2)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-bold text-slate-400 uppercase leading-none mb-1">New Balance</p>
                      <div className="text-sm font-black text-slate-900">€{item.bankrollAfter.toFixed(2)}</div>
                      <div className={cn(
                        "text-[9px] font-bold",
                        item.outcome === 'W' ? "text-emerald-500" : "text-rose-500"
                      )}>
                        {item.outcome === 'W' ? '+' : '-'}€{(item.outcome === 'W' ? item.stake*(odds-1) : item.stake).toFixed(2)}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Desktop Table View */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-50 bg-slate-50/50 text-nowrap">
                  <th className="px-6 py-3 text-[10px] font-black uppercase text-slate-400 whitespace-nowrap">Event</th>
                  <th className="px-6 py-3 text-[10px] font-black uppercase text-slate-400 whitespace-nowrap">Status</th>
                  <th className="px-6 py-3 text-[10px] font-black uppercase text-slate-400 whitespace-nowrap">Staked</th>
                  <th className="px-6 py-3 text-[10px] font-black uppercase text-slate-400 whitespace-nowrap">Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {[...derived.historyItems].reverse().map(item => (
                  <tr key={item.eventNumber} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-4 text-xs font-bold text-slate-500">#{item.eventNumber}</td>
                    <td className="px-6 py-4">
                      <div className={cn(
                        "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase",
                        item.outcome === 'W' ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
                      )}>
                        {item.outcome === 'W' ? "Winning" : "Losing"}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-xs font-black text-slate-900">€{item.stake.toFixed(2)}</td>
                    <td className="px-6 py-4">
                      <div className="text-xs font-black text-slate-900 tabular-nums">€{item.bankrollAfter.toFixed(2)}</div>
                      <div className={cn(
                        "text-[9px] font-bold tabular-nums",
                        item.outcome === 'W' ? "text-emerald-500" : "text-rose-500"
                      )}>
                        {item.outcome === 'W' ? '+' : '-'}€{(item.outcome === 'W' ? item.stake*(odds-1) : item.stake).toFixed(2)}
                      </div>
                    </td>
                  </tr>
                ))}
                {history.length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-6 py-12 text-center text-slate-400 text-xs font-medium italic">
                      Recording will appear here once you start.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Minimalist Components ---

function InputGroup({ label, value, onChange, icon: Icon, step = "1" }: { label: string; value: number; onChange: (v: string) => void; icon: any; step?: string }) {
  return (
    <div className="space-y-2">
      <label className="text-[10px] uppercase font-black text-slate-400 tracking-widest flex items-center gap-2">
        <Icon className="w-3 h-3" />
        {label}
      </label>
      <input 
        type="number"
        step={step}
        value={value}
        onChange={e => onChange(e.target.value)}
        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-blue-100 focus:border-blue-500 transition-all font-black text-slate-900 tabular-nums"
      />
    </div>
  );
}

function StatRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-xs font-bold text-slate-400">{label}</span>
      <span className="text-xs font-black text-slate-700 font-mono tracking-tight">{value}</span>
    </div>
  );
}

function ActionButton({ label, color, icon: Icon, onClick }: { label: string; color: 'emerald' | 'rose'; icon: any; onClick: () => void }) {
  const styles = {
    emerald: "bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200 text-white",
    rose: "bg-rose-600 hover:bg-rose-700 shadow-rose-200 text-white"
  };
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-2 p-5 rounded-2xl transition-all shadow-xl active:scale-95",
        styles[color]
      )}
    >
      <Icon className="w-6 h-6" />
      <span className="text-[10px] font-black uppercase tracking-widest">{label}</span>
    </button>
  );
}

function BentoStat({ label, value, sub, icon: Icon, trend }: { label: string; value: string; sub?: string; icon: any; trend?: 'up' | 'down' }) {
  return (
    <div className="bg-white rounded-3xl border border-slate-200 p-6 flex items-center justify-between shadow-sm relative overflow-hidden group">
      <div className="relative z-10">
        <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">{label}</p>
        <p className="text-2xl font-black text-slate-900 tracking-tight">{value}</p>
        {sub && <p className="text-[10px] font-bold text-slate-500 mt-1 uppercase tracking-tight">{sub}</p>}
      </div>
      <div className={cn(
        "p-3 rounded-2xl transition-colors",
        trend === 'up' ? "bg-emerald-50 text-emerald-600" : trend === 'down' ? "bg-rose-50 text-rose-600" : "bg-slate-50 text-slate-400"
      )}>
        <Icon className="w-5 h-5" />
      </div>
    </div>
  );
}

